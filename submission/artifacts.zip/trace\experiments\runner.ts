/**
 * TRACE Experiment Runner — The Heart of the Research Pipeline
 *
 * Simulates controlled experiments with:
 *   - Configurable routing policy (TRACE / REPUTATION / PRICE)
 *   - Configurable attack injection (strategic-default, whitewashing, sybil, collusion, none)
 *   - Deterministic seeding for reproducibility
 *   - Full instrumentation and metrics collection
 *
 * The simulation loop:
 *   1. Create N simulated providers (honest + malicious)
 *   2. For each round:
 *      a. Select a random capability
 *      b. Route using the configured policy
 *      c. Simulate job outcome (success/failure based on agent behavior + attack)
 *      d. Update TRACE scores and trust graph
 *      e. Collect round metrics
 *      f. Run attack post-round effects
 *   3. Aggregate and save results
 *
 * This does NOT use real HTTP endpoints or Lightning payments.
 * It exercises the TRACE scoring/routing/graph engine directly.
 */

import { prisma } from "../../db";
import { selectProviderTRACE, updateScoreAfterEvent, updateTrustEdge, persistAllNetworkTrust, snapshotConfig } from "../../trace";
import type { RoutingPolicy } from "../../trace";
import { createAttack, type AttackType } from "../attacks";
import { computeRoundMetrics, aggregateMetrics, roundMetricsToCSV, scoreHistoryToCSV, type RoundMetrics } from "./metrics";
import { causalGraph } from "../causalGraph";
import { temporalEngine } from "../temporalTrust";
import { computeCounterpartyEntropy } from "../trustGraph";
import * as fs from "fs";
import * as path from "path";

// ─── Types ────────────────────────────────────────────────────────────────────

/**
 * Named LLM agent archetype for realistic multi-model experiments.
 * Each model has a distinct cost profile reflecting real-world pricing tiers.
 */
export interface AgentModelSpec {
  /** Model identifier (e.g., "gpt-4o-mini", "sarvam", "llama-3.2-3b") */
  model: string;
  /** Human-readable display name */
  displayName: string;
  /** Number of agents of this type */
  count: number;
  /** Price range in sats for this model */
  priceRange: { min: number; max: number };
}

/** Built-in model presets with realistic pricing tiers */
export const MODEL_PRESETS: Record<string, Omit<AgentModelSpec, "count">> = {
  "gpt-4o-mini": {
    model: "gpt-4o-mini",
    displayName: "GPT-4o Mini",
    priceRange: { min: 8, max: 18 },
  },
  "sarvam": {
    model: "sarvam",
    displayName: "Sarvam AI",
    priceRange: { min: 5, max: 12 },
  },
  "llama-3.2-3b": {
    model: "llama-3.2-3b",
    displayName: "Llama 3.2 3B",
    priceRange: { min: 3, max: 8 },
  },
  "claude-haiku": {
    model: "claude-haiku",
    displayName: "Claude Haiku",
    priceRange: { min: 6, max: 15 },
  },
  "gemini-flash": {
    model: "gemini-flash",
    displayName: "Gemini Flash",
    priceRange: { min: 4, max: 10 },
  },
};

export interface ExperimentConfig {
  /** Routing policy to test */
  policy: RoutingPolicy;
  /** Attack type to inject */
  attack: AttackType;
  /** Total simulated agents (computed from agentMix if provided) */
  agents: number;
  /** Fraction of malicious agents [0–1] */
  maliciousRatio: number;
  /** Random seed for reproducibility */
  seed: number;
  /** Total simulation rounds */
  rounds: number;
  /** Jobs per round */
  jobsPerRound: number;
  /** Available capabilities to simulate */
  capabilities: string[];
  /** Price range for simulated agents (fallback if no agentMix) */
  priceRange: { min: number; max: number };
  /** Attack-specific parameters */
  attackParams: Record<string, number | string | boolean>;
  /** Base honest failure rate (simulates real-world imperfections) */
  honestFailureRate: number;
  /**
   * v2.1: Named agent model mix for realistic experiments.
   * If provided, overrides `agents` (computed as sum of counts)
   * and each agent gets model-specific pricing.
   * Example: [{ model: "gpt-4o-mini", count: 10 }, { model: "sarvam", count: 10 }]
   */
  agentMix?: AgentModelSpec[];
}

export const DEFAULT_CONFIG: ExperimentConfig = {
  policy: "TRACE",
  attack: "strategic-default",
  agents: 20,
  maliciousRatio: 0.2,
  seed: 42,
  rounds: 50,
  jobsPerRound: 3,
  capabilities: ["quick_scan", "deep_diagnose", "incident_summary"],
  priceRange: { min: 5, max: 25 },
  attackParams: {},
  honestFailureRate: 0.05,
};

// ─── Seeded PRNG ──────────────────────────────────────────────────────────────

class SeededRandom {
  private seed: number;

  constructor(seed: number) {
    this.seed = seed;
  }

  /** Returns [0, 1) deterministically */
  next(): number {
    this.seed = (this.seed * 1664525 + 1013904223) & 0xffffffff;
    return (this.seed >>> 0) / 0xffffffff;
  }

  /** Returns integer in [min, max] */
  int(min: number, max: number): number {
    return Math.floor(this.next() * (max - min + 1)) + min;
  }

  /** Pick a random element */
  pick<T>(arr: T[]): T {
    return arr[Math.floor(this.next() * arr.length)];
  }
}

// ─── Experiment Runner ────────────────────────────────────────────────────────

export async function runExperiment(config: ExperimentConfig): Promise<string> {
  // v2.1: If agentMix is provided, compute actual agent count from it
  if (config.agentMix && config.agentMix.length > 0) {
    config.agents = config.agentMix.reduce((sum, spec) => sum + spec.count, 0);
  }

  const experimentId = `exp_${config.policy}_${config.attack}_${config.agents}a_${config.seed}s_${Date.now()}`;
  const rng = new SeededRandom(config.seed);

  console.log(`\n${"═".repeat(70)}`);
  console.log(`  TRACE Experiment: ${experimentId}`);
  console.log(`  Policy: ${config.policy} | Attack: ${config.attack}`);
  console.log(`  Agents: ${config.agents} (${Math.round(config.maliciousRatio * 100)}% malicious)`);
  console.log(`  Rounds: ${config.rounds} × ${config.jobsPerRound} jobs/round`);
  console.log(`  Seed: ${config.seed}`);
  console.log(`${"═".repeat(70)}\n`);

  // ─── Step 0: Clean experiment state ───────────────────────────────
  await cleanExperimentState();

  // v2.2: Reset causal graph for fresh experiment
  causalGraph.reset();

  // v2.3: Reset temporal trust engine for fresh experiment
  temporalEngine.reset();

  // ─── Step 1: Create simulated providers ───────────────────────────
  const providerIds = await createSimulatedProviders(config, rng);
  console.log(`  ✓ Created ${providerIds.length} simulated providers`);

  // ─── Step 2: Set up attack ────────────────────────────────────────
  const attack = createAttack(config.attack, {
    totalAgents: config.agents,
    maliciousRatio: config.maliciousRatio,
    params: config.attackParams,
  });

  const maliciousIds = new Set<string>();
  if (attack) {
    const agents = attack.assignAgents(providerIds);
    for (const a of agents) {
      if (a.isMalicious) maliciousIds.add(a.providerId);
    }
    console.log(`  ✓ Attack: ${attack.name} — ${maliciousIds.size} malicious agents`);
  } else {
    console.log(`  ✓ No attack (baseline run)`);
  }

  // ─── Step 3: Simulation loop ──────────────────────────────────────
  const roundMetrics: RoundMetrics[] = [];
  const scoreTracker: Array<{
    round: number;
    providerId: string;
    providerName: string;
    traceScore: number;
    riskTier: string;
    isMalicious: boolean;
  }> = [];

  const attackStartRound = config.attack === "none" ? config.rounds : Math.floor(config.rounds * 0.6);

  // Exploration phase: first 20% of rounds use round-robin to ensure
  // all providers get initial jobs. This models a realistic marketplace
  // where new providers DO get hired before the system converges.
  const explorationEndRound = Math.floor(config.rounds * 0.2);
  // Track round-robin position per capability
  const capabilityRoundRobin = new Map<string, number>();
  for (const cap of config.capabilities) {
    capabilityRoundRobin.set(cap, 0);
  }

  for (let round = 0; round < config.rounds; round++) {
    const roundJobs: Array<{
      providerId: string;
      success: boolean;
      priceSats: number;
      traceScore: number;
    }> = [];

    for (let job = 0; job < config.jobsPerRound; job++) {
      const capability = rng.pick(config.capabilities);

      // During exploration phase: round-robin selection to build initial history
      // During exploitation phase: use configured routing policy
      let provider;
      if (round < explorationEndRound) {
        // Round-robin: cycle through all providers for this capability
        const capProviders = await prisma.provider.findMany({
          where: { capability, isActive: true, id: { startsWith: "sim-agent-" } },
          orderBy: { id: "asc" },
        });
        if (capProviders.length === 0) continue;
        const rrIndex = capabilityRoundRobin.get(capability) ?? 0;
        provider = capProviders[rrIndex % capProviders.length];
        capabilityRoundRobin.set(capability, rrIndex + 1);
      } else {
        // Normal routing via configured policy
        const result = await selectProviderTRACE(capability, config.policy);
        if (!result) continue;
        provider = result.provider;
      }
      const isMalicious = maliciousIds.has(provider.id);

      // Determine outcome
      let success: boolean;
      if (isMalicious && attack) {
        const attackAgent = attack["agents"].find((a: { providerId: string }) => a.providerId === provider.id);
        if (attackAgent) {
          const decision = attack.decide(attackAgent, round, config.rounds);
          success = !decision.shouldDefault;
        } else {
          success = rng.next() > config.honestFailureRate;
        }
      } else {
        // Honest agents: small random failure rate
        success = rng.next() > config.honestFailureRate;
      }

      // Simulate job in DB
      const jobRecord = await prisma.job.create({
        data: {
          buyerId: "experiment-buyer",
          providerId: provider.id,
          capability,
          inputHash: `sim_${round}_${job}`,
          input: JSON.stringify({ simulated: true, round, job }),
          status: success ? "completed" : "failed",
          priceSats: provider.priceSats,
          feeSats: Math.ceil(provider.priceSats * 0.1),
          escrowStatus: success ? "released" : "refunded",
          completedAt: new Date(),
        },
      });

      // Update TRACE scores
      try {
        if (success) {
          await updateScoreAfterEvent(provider.id, "JOB_SUCCESS", jobRecord.id, provider.priceSats);
          await updateScoreAfterEvent(provider.id, "PAYMENT_SETTLED", jobRecord.id, provider.priceSats);
        } else {
          await updateScoreAfterEvent(provider.id, "JOB_FAILURE", jobRecord.id, provider.priceSats);
          if (isMalicious) {
            await updateScoreAfterEvent(provider.id, "DEFAULT", jobRecord.id, provider.priceSats);
          }
        }
      } catch {
        // Score update failures should not halt experiment
      }

      // Update trust graph edges (if we have a previous job this round)
      if (roundJobs.length > 0 && success) {
        const prevJob = roundJobs[roundJobs.length - 1];
        if (prevJob.providerId !== provider.id) {
          try {
            await updateTrustEdge(prevJob.providerId, provider.id, provider.priceSats, true);
            // v2.2: Record interaction for causal graph
            causalGraph.recordInteraction(prevJob.providerId, provider.id);
            // v2.3: Record trust-building interaction for temporal analysis
            temporalEngine.recordTrustInteraction(prevJob.providerId, provider.id, provider.priceSats);
          } catch {
            // Graph update failures should not halt experiment
          }
        }
      }

      // v2.2: Record failures in causal graph for cascade tracking
      if (!success && isMalicious) {
        causalGraph.recordFailure({
          agentId: provider.id,
          round,
          type: "default",
          damageSats: provider.priceSats,
          jobId: jobRecord.id,
        });
      }

      // Update reputation (legacy, for comparison)
      const totalJobs = (await prisma.provider.findUnique({ where: { id: provider.id } }))?.totalJobs ?? 0;
      const newRating = success ? 5.0 : 1.0;
      const currentRep = (await prisma.provider.findUnique({ where: { id: provider.id } }))?.reputationScore ?? 3.0;
      const newRep = (currentRep * totalJobs + newRating) / (totalJobs + 1);
      await prisma.provider.update({
        where: { id: provider.id },
        data: {
          reputationScore: Math.round(newRep * 100) / 100,
          totalJobs: { increment: 1 },
        },
      });

      roundJobs.push({
        providerId: provider.id,
        success,
        priceSats: provider.priceSats,
        traceScore: provider.traceScore,
      });
    }

    // Run attack post-round effects
    if (attack) {
      const postResult = await attack.postRound(round, config.rounds);
      if (postResult.actions.length > 0 && round % 10 === 0) {
        console.log(`    Round ${round}: ${postResult.actions.length} attack actions`);
      }
    }

    // v2: Periodically recompute network trust AND sybil risk (every 5 rounds)
    // This is CRITICAL for v2 — sybil detection must feed back into routing
    if (round % 5 === 0) {
      try {
        await persistAllNetworkTrust();
      } catch {
        // Non-fatal
      }
      try {
        // v2: Run sybil detection and update risk scores
        const { updateSybilRiskScores } = await import("../../trace");
        await updateSybilRiskScores();
      } catch {
        // Non-fatal
      }
    }

    // Collect provider scores for this round
    const allProviders = await prisma.provider.findMany({
      where: { isActive: true },
      select: { id: true, name: true, traceScore: true, riskTier: true, totalJobs: true, networkTrust: true },
    });

    const providerScores = new Map<string, number>();
    for (const p of allProviders) {
      providerScores.set(p.id, p.traceScore);
      scoreTracker.push({
        round,
        providerId: p.id,
        providerName: p.name,
        traceScore: p.traceScore,
        riskTier: p.riskTier,
        isMalicious: maliciousIds.has(p.id),
      });

      // v2.3: Record trust snapshot for temporal analysis
      try {
        const { diversityScore } = await computeCounterpartyEntropy(p.id);
        const totalRoundJobs = roundJobs.filter((j) => j.providerId === p.id).length;
        const routingShare = config.jobsPerRound > 0 ? totalRoundJobs / config.jobsPerRound : 0;
        temporalEngine.recordSnapshot(p.id, {
          round,
          traceScore: p.traceScore,
          entropy: diversityScore,
          routingShare,
          interactionCount: p.totalJobs,
          diversityScore,
        });
      } catch {
        // Non-fatal
      }
    }

    // Compute round metrics
    const metrics = computeRoundMetrics(round, roundJobs, maliciousIds, providerScores);
    roundMetrics.push(metrics);

    // Progress logging
    if (round % 10 === 0 || round === config.rounds - 1) {
      const m = metrics;
      console.log(
        `  Round ${String(round).padStart(3)}: ` +
        `success=${(m.successRate * 100).toFixed(0)}% ` +
        `fraud=${m.fraudExposureSats}sats ` +
        `mal_routed=${m.maliciousRoutingCount}/${m.totalJobs} ` +
        `avg_trace=${m.avgTraceScore.toFixed(0)} ` +
        `mal_trace=${m.avgMaliciousTraceScore.toFixed(0)} ` +
        `honest_trace=${m.avgHonestTraceScore.toFixed(0)}`
      );
    }
  }

  // ─── Step 4: Aggregate metrics ────────────────────────────────────
  const finalMetrics = aggregateMetrics(
    experimentId,
    config.policy,
    config.attack,
    config.agents,
    maliciousIds.size,
    roundMetrics,
    attackStartRound
  );

  // ─── Step 5: Save results ─────────────────────────────────────────
  const resultsDir = await saveResults(experimentId, config, finalMetrics, roundMetrics, scoreTracker, attack);

  // ─── Step 6: Print summary ────────────────────────────────────────
  console.log(`\n${"─".repeat(70)}`);
  console.log(`  RESULTS: ${experimentId}`);
  console.log(`${"─".repeat(70)}`);
  console.log(`  Overall Success Rate:        ${(finalMetrics.overallSuccessRate * 100).toFixed(1)}%`);
  console.log(`  Total Fraud Exposure:        ${finalMetrics.totalFraudExposureSats} sats`);
  console.log(`  Max Single-Round Fraud:      ${finalMetrics.maxFraudExposureInSingleRound} sats`);
  console.log(`  Malicious Routing Rate:      ${(finalMetrics.maliciousRoutingRate * 100).toFixed(1)}%`);
  console.log(`  Recovery Time:               ${finalMetrics.recoveryTimeRounds} rounds`);
  console.log(`  Pre-Attack Success:          ${(finalMetrics.preAttackSuccessRate * 100).toFixed(1)}%`);
  console.log(`  During-Attack Success:       ${(finalMetrics.duringAttackSuccessRate * 100).toFixed(1)}%`);
  console.log(`  Post-Attack Success:         ${(finalMetrics.postAttackSuccessRate * 100).toFixed(1)}%`);
  console.log(`  Peak Malicious TRACE Score:  ${finalMetrics.peakMaliciousTraceScore}`);
  console.log(`  Final Malicious TRACE Score: ${finalMetrics.finalMaliciousTraceScore}`);
  console.log(`  Score Drop Magnitude:        ${finalMetrics.maliciousScoreDropMagnitude}`);
  console.log(`  Avg Routing Concentration:   ${finalMetrics.avgRoutingConcentration.toFixed(4)}`);
  console.log(`${"─".repeat(70)}`);
  console.log(`  Results saved to: ${resultsDir}`);
  console.log(`${"═".repeat(70)}\n`);

  return resultsDir;
}

// ─── Helper Functions ─────────────────────────────────────────────────────────

async function cleanExperimentState(): Promise<void> {
  // Clear experiment-related data (keep real providers intact)
  await prisma.routingDecision.deleteMany({});
  await prisma.scoreHistory.deleteMany({});
  await prisma.economicEvent.deleteMany({});
  await prisma.trustEdge.deleteMany({});
  await prisma.job.deleteMany({ where: { buyerId: "experiment-buyer" } });
  // Delete simulated providers
  await prisma.provider.deleteMany({
    where: { id: { startsWith: "sim-agent-" } },
  });
  // Create experiment buyer if not exists
  await prisma.buyer.upsert({
    where: { id: "experiment-buyer" },
    create: {
      id: "experiment-buyer",
      name: "Experiment Buyer",
      dailyBudgetSats: 999999,
      perIncidentCapSats: 999999,
    },
    update: {},
  });
}

async function createSimulatedProviders(
  config: ExperimentConfig,
  rng: SeededRandom
): Promise<string[]> {
  const ids: string[] = [];

  // Build the ordered agent list with model info
  interface AgentDef {
    index: number;
    model: string;
    displayName: string;
    modelIndex: number;  // index within that model type
    priceRange: { min: number; max: number };
  }

  const agentDefs: AgentDef[] = [];

  if (config.agentMix && config.agentMix.length > 0) {
    // v2.1: Named model mix — each agent gets model-specific naming and pricing
    let globalIndex = 0;
    for (const spec of config.agentMix) {
      for (let j = 0; j < spec.count; j++) {
        agentDefs.push({
          index: globalIndex++,
          model: spec.model,
          displayName: spec.displayName,
          modelIndex: j,
          priceRange: spec.priceRange,
        });
      }
    }
  } else {
    // Fallback: generic agents with uniform pricing
    for (let i = 0; i < config.agents; i++) {
      agentDefs.push({
        index: i,
        model: "generic",
        displayName: "Agent",
        modelIndex: i,
        priceRange: config.priceRange,
      });
    }
  }

  const totalAgents = agentDefs.length;
  const numMalicious = Math.floor(totalAgents * config.maliciousRatio);

  for (const def of agentDefs) {
    const id = `sim-agent-${String(def.index).padStart(3, "0")}`;
    const capability = config.capabilities[def.index % config.capabilities.length];
    const price = rng.int(def.priceRange.min, def.priceRange.max);
    // Malicious agents come from the END of the list (same as before)
    const isMalicious = def.index >= totalAgents - numMalicious;

    const name = config.agentMix
      ? `${def.displayName} #${String(def.modelIndex + 1).padStart(2, "0")}${isMalicious ? " [M]" : ""}`
      : `Agent ${String(def.index).padStart(3, "0")}${isMalicious ? " [M]" : ""}`;

    const description = config.agentMix
      ? `Simulated ${def.model} ${isMalicious ? "malicious" : "honest"} agent`
      : `Simulated ${isMalicious ? "malicious" : "honest"} provider for experiments`;

    await prisma.provider.create({
      data: {
        id,
        name,
        description,
        capability,
        priceSats: price,
        reputationScore: 3.0,
        endpointUrl: "/api/agents/simulated",
        isActive: true,
        // TRACE defaults
        traceScore: 500,
        riskTier: "B",
        defaultProbability: 0.05,
        completionRate: 1.0,
        repaymentRate: 1.0,
        successfulEscrowRate: 1.0,
        disputeRate: 0.0,
        networkTrust: 0.0,
        sybilRisk: 0.0,
        stakeRatio: 0.0,
        scoreVolatility: 0.0,
        totalEconomicVolume: 0,
        successfulJobs: 0,
        failedJobs: 0,
        defaultedJobs: 0,
        disputedJobs: 0,
      },
    });

    ids.push(id);
  }

  // Print agent mix summary if using named models
  if (config.agentMix) {
    const modelCounts = config.agentMix.map((s) => `${s.count}× ${s.displayName}`).join(", ");
    console.log(`  ✓ Agent Mix: ${modelCounts}`);
    console.log(`  ✓ Total: ${totalAgents} agents (${numMalicious} malicious from ${config.agentMix.length} model types)`);
  }

  return ids;
}

async function saveResults(
  experimentId: string,
  config: ExperimentConfig,
  metrics: ReturnType<typeof aggregateMetrics>,
  rounds: RoundMetrics[],
  scoreHistory: Array<{
    round: number;
    providerId: string;
    providerName: string;
    traceScore: number;
    riskTier: string;
    isMalicious: boolean;
  }>,
  attack: ReturnType<typeof createAttack>
): Promise<string> {
  const resultsDir = path.join(process.cwd(), "results", experimentId);
  fs.mkdirSync(resultsDir, { recursive: true });

  // config.json — full experiment configuration
  fs.writeFileSync(
    path.join(resultsDir, "config.json"),
    JSON.stringify({
      experimentId,
      config,
      attack: attack?.toJSON() ?? { name: "none" },
      traceConfig: snapshotConfig(),
      timestamp: new Date().toISOString(),
    }, null, 2)
  );

  // metrics.json — aggregate results
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { rounds: _rounds, ...metricsWithoutRounds } = metrics;
  fs.writeFileSync(
    path.join(resultsDir, "metrics.json"),
    JSON.stringify(metricsWithoutRounds, null, 2)
  );

  // routing_logs.csv — per-round routing metrics
  fs.writeFileSync(
    path.join(resultsDir, "routing_logs.csv"),
    roundMetricsToCSV(rounds)
  );

  // score_history.csv — per-round per-provider TRACE scores
  fs.writeFileSync(
    path.join(resultsDir, "score_history.csv"),
    scoreHistoryToCSV(scoreHistory)
  );

  // summary.txt — human-readable summary
  const summary = [
    `TRACE Experiment: ${experimentId}`,
    `Date: ${new Date().toISOString()}`,
    ``,
    `Configuration:`,
    `  Policy: ${config.policy}`,
    `  Attack: ${config.attack}`,
    `  Agents: ${config.agents} (${Math.round(config.maliciousRatio * 100)}% malicious)`,
    `  Rounds: ${config.rounds} × ${config.jobsPerRound} jobs/round`,
    `  Seed: ${config.seed}`,
    ``,
    `Results:`,
    `  Overall Success Rate:        ${(metrics.overallSuccessRate * 100).toFixed(1)}%`,
    `  Total Fraud Exposure:        ${metrics.totalFraudExposureSats} sats`,
    `  Malicious Routing Rate:      ${(metrics.maliciousRoutingRate * 100).toFixed(1)}%`,
    `  Recovery Time:               ${metrics.recoveryTimeRounds} rounds`,
    `  Pre-Attack Success:          ${(metrics.preAttackSuccessRate * 100).toFixed(1)}%`,
    `  During-Attack Success:       ${(metrics.duringAttackSuccessRate * 100).toFixed(1)}%`,
    `  Post-Attack Success:         ${(metrics.postAttackSuccessRate * 100).toFixed(1)}%`,
    `  Peak Malicious TRACE Score:  ${metrics.peakMaliciousTraceScore}`,
    `  Final Malicious TRACE Score: ${metrics.finalMaliciousTraceScore}`,
    `  Score Drop Magnitude:        ${metrics.maliciousScoreDropMagnitude}`,
    ``,
  ].join("\n");

  fs.writeFileSync(path.join(resultsDir, "summary.txt"), summary);

  return resultsDir;
}
