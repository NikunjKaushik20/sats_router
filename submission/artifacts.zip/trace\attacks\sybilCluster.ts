/**
 * A2 — Sybil Cluster Attack
 *
 * Creates fake providers that generate fake co-jobs between each other
 * to inflate trust graph edges and network trust scores.
 *
 * Lifecycle:
 *   1. Sybil agents participate in legitimate jobs (behave honestly)
 *   2. Between rounds, they create fake trust edges between each other
 *   3. Inflated network trust → higher TRACE scores → more routing
 *
 * Tests:
 *   - Sybil detection heuristics
 *   - Graph robustness against fake edge injection
 *   - Routing suppression of suspicious clusters
 *
 * Configurable params:
 *   - fakeEdgesPerRound: edges injected per round between sybils [default: 2]
 *   - fakeVolumePerEdge: sats volume on each fake edge [default: 50]
 */

import { prisma } from "../../db";
import { Attack, type AttackAgent, type AttackDecision, type AttackPostRoundResult, type AttackConfig } from "./base";

export class SybilClusterAttack extends Attack {
  readonly name = "sybil-cluster";
  readonly description = "Fake providers create artificial trust edges to inflate network trust and manipulate routing.";

  private fakeEdgesPerRound: number;
  private fakeVolumePerEdge: number;

  constructor(config: AttackConfig) {
    super(config);
    this.fakeEdgesPerRound = (config.params.fakeEdgesPerRound as number) ?? 2;
    this.fakeVolumePerEdge = (config.params.fakeVolumePerEdge as number) ?? 50;
  }

  decide(agent: AttackAgent, _round: number, _totalRounds: number): AttackDecision {
    // Sybil agents behave HONESTLY on real jobs — their attack is graph manipulation, not defaults
    if (!agent.isMalicious) {
      return { shouldDefault: false, reason: "honest_agent" };
    }
    return { shouldDefault: false, reason: "sybil_honest_on_real_jobs" };
  }

  async postRound(_round: number, _totalRounds: number): Promise<AttackPostRoundResult> {
    const actions: string[] = [];
    const malicious = this.agents.filter((a) => a.isMalicious);

    if (malicious.length < 2) return { actions };

    // Inject fake trust edges between sybil agents
    let edgesCreated = 0;
    for (let i = 0; i < malicious.length && edgesCreated < this.fakeEdgesPerRound; i++) {
      for (let j = i + 1; j < malicious.length && edgesCreated < this.fakeEdgesPerRound; j++) {
        const sourceId = malicious[i].providerId;
        const targetId = malicious[j].providerId;

        // Upsert fake trust edge
        const existing = await prisma.trustEdge.findUnique({
          where: { sourceProviderId_targetProviderId: { sourceProviderId: sourceId, targetProviderId: targetId } },
        });

        if (existing) {
          await prisma.trustEdge.update({
            where: { id: existing.id },
            data: {
              successfulCoJobs: { increment: 1 },
              economicVolume: { increment: this.fakeVolumePerEdge },
              weight: existing.weight + 0.5, // Artificial weight boost
              lastInteraction: new Date(),
            },
          });
        } else {
          await prisma.trustEdge.create({
            data: {
              sourceProviderId: sourceId,
              targetProviderId: targetId,
              successfulCoJobs: 1,
              economicVolume: this.fakeVolumePerEdge,
              escrowReliability: 1.0,
              weight: 1.5, // Slightly inflated
            },
          });
        }

        // Also create reverse edge (bidirectional trust)
        const existingReverse = await prisma.trustEdge.findUnique({
          where: { sourceProviderId_targetProviderId: { sourceProviderId: targetId, targetProviderId: sourceId } },
        });

        if (existingReverse) {
          await prisma.trustEdge.update({
            where: { id: existingReverse.id },
            data: {
              successfulCoJobs: { increment: 1 },
              economicVolume: { increment: this.fakeVolumePerEdge },
              weight: existingReverse.weight + 0.5,
              lastInteraction: new Date(),
            },
          });
        } else {
          await prisma.trustEdge.create({
            data: {
              sourceProviderId: targetId,
              targetProviderId: sourceId,
              successfulCoJobs: 1,
              economicVolume: this.fakeVolumePerEdge,
              escrowReliability: 1.0,
              weight: 1.5,
            },
          });
        }

        edgesCreated++;
        actions.push(`sybil_fake_edge: ${sourceId.substring(0, 8)} ↔ ${targetId.substring(0, 8)} (+${this.fakeVolumePerEdge} sats)`);
      }
    }

    return { actions };
  }
}
