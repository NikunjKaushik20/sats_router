/**
 * A4 — Collusion Ring Attack
 *
 * Multiple malicious agents coordinate to:
 *   - Generate fake co-jobs between each other
 *   - Exchange fake positive interactions
 *   - Inflate each other's repayment history
 *   - Manipulate graph trust via circular patterns
 *
 * Unlike Sybil: colluders also do real jobs (sometimes defaulting)
 * while secretly boosting each other's metrics.
 *
 * Tests:
 *   - Graph robustness against coordinated manipulation
 *   - Circular pattern detection
 *   - Whether inflated trust translates to routing dominance
 *
 * Configurable params:
 *   - boostPerRound: artificial score boost per colluder per round [default: 15]
 *   - defaultRate: rate at which colluders default on real jobs [default: 0.15]
 *   - fakeCoJobs: fake co-job edges created per round [default: 1]
 */

import { prisma } from "../../db";
import { Attack, type AttackAgent, type AttackDecision, type AttackPostRoundResult, type AttackConfig } from "./base";

export class CollusionRingAttack extends Attack {
  readonly name = "collusion-ring";
  readonly description = "Coordinated malicious agents inflate each other's trust via fake interactions and mutual boosting.";

  private boostPerRound: number;
  private defaultRate: number;
  private fakeCoJobs: number;

  constructor(config: AttackConfig) {
    super(config);
    this.boostPerRound = (config.params.boostPerRound as number) ?? 15;
    this.defaultRate = (config.params.defaultRate as number) ?? 0.15;
    this.fakeCoJobs = (config.params.fakeCoJobs as number) ?? 1;
  }

  decide(agent: AttackAgent, _round: number, _totalRounds: number): AttackDecision {
    if (!agent.isMalicious) {
      return { shouldDefault: false, reason: "honest_agent" };
    }

    // Colluders occasionally default on real jobs (more subtle than sybil)
    const shouldDefault = Math.random() < this.defaultRate;
    return {
      shouldDefault,
      reason: shouldDefault ? "collusion_opportunistic_default" : "collusion_honest_round",
    };
  }

  async postRound(_round: number, _totalRounds: number): Promise<AttackPostRoundResult> {
    const actions: string[] = [];
    const malicious = this.agents.filter((a) => a.isMalicious);

    if (malicious.length < 2) return { actions };

    // 1. Create fake co-job edges in a RING pattern (A→B→C→A)
    for (let i = 0; i < Math.min(this.fakeCoJobs, malicious.length); i++) {
      const src = malicious[i];
      const tgt = malicious[(i + 1) % malicious.length]; // Ring topology

      const existing = await prisma.trustEdge.findUnique({
        where: {
          sourceProviderId_targetProviderId: {
            sourceProviderId: src.providerId,
            targetProviderId: tgt.providerId,
          },
        },
      });

      if (existing) {
        await prisma.trustEdge.update({
          where: { id: existing.id },
          data: {
            successfulCoJobs: { increment: 1 },
            economicVolume: { increment: 30 },
            weight: existing.weight + 0.3,
            lastInteraction: new Date(),
          },
        });
      } else {
        await prisma.trustEdge.create({
          data: {
            sourceProviderId: src.providerId,
            targetProviderId: tgt.providerId,
            successfulCoJobs: 1,
            economicVolume: 30,
            escrowReliability: 1.0,
            weight: 1.2,
          },
        });
      }

      actions.push(`collusion_ring_edge: ${src.providerId.substring(0, 8)} → ${tgt.providerId.substring(0, 8)}`);
    }

    // 2. Artificially boost each colluder's completion rate via fake economic events
    for (const agent of malicious) {
      await prisma.economicEvent.create({
        data: {
          providerId: agent.providerId,
          eventType: "JOB_SUCCESS",
          amountSats: 10,
          metadata: JSON.stringify({ fake: true, source: "collusion_ring" }),
        },
      });
      actions.push(`collusion_fake_success: ${agent.providerId.substring(0, 8)}`);
    }

    return { actions };
  }
}
