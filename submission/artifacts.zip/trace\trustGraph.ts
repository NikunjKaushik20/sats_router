/**
 * TRACE v2.2 Trust Graph Engine — Adaptive + Causal
 *
 * v2.2 additions:
 *   - Maturity-aware repeated-pair decay: k_eff = k × maturityFactor
 *   - Confidence-gated diversity scoring
 *   - Causal-aware trust persistence
 *
 * v2.1 features (maintained):
 *   - Counterparty entropy: H = -Σ pᵢ·log₂(pᵢ) per provider
 *   - Repeated-pair suppression: trust gain *= exp(-count/k)
 *   - Economic volume weighting: tiny transactions give less trust
 *   - Diversity-adjusted trust: AdjustedTrust = networkTrust × diversityScore
 *   - Loop suspicion score integrated into sybilRisk
 *
 * v2 features (maintained):
 *   - Edge weight saturation caps
 *   - Trust saturation with logarithmic scaling
 *   - Circular trust detection with penalty amplification
 *   - Stronger sybil risk scoring
 */

import { prisma } from "../db";
import {
  TRUST_DECAY,
  TRUST_GRAPH_VALIDATION,
  COUNTERPARTY_DIVERSITY,
  REPEATED_PAIR,
  ECONOMIC_VOLUME_WEIGHTING,
} from "./config";
import { computeEntropyConfidence, effectiveDecayConstant } from "./adaptiveConfig";

// ─── Trust Edge Management ────────────────────────────────────────────────────

/**
 * Update or create a trust edge after two providers participate in the same
 * orchestration (co-job). v2: applies edge weight cap and diversity checks.
 */
export async function updateTrustEdge(
  sourceProviderId: string,
  targetProviderId: string,
  jobAmountSats: number,
  escrowSuccess: boolean
): Promise<void> {
  if (sourceProviderId === targetProviderId) return;

  const existing = await prisma.trustEdge.findUnique({
    where: {
      sourceProviderId_targetProviderId: {
        sourceProviderId,
        targetProviderId,
      },
    },
  });

  if (existing) {
    const newCoJobs = existing.successfulCoJobs + 1;
    const newVolume = existing.economicVolume + jobAmountSats;
    const newReliability = escrowSuccess
      ? (existing.escrowReliability * existing.successfulCoJobs + 1.0) / newCoJobs
      : (existing.escrowReliability * existing.successfulCoJobs + 0.0) / newCoJobs;

    // v2: Compute edge weight with SATURATION CAP
    let weight = computeEdgeWeight(newCoJobs, newVolume, newReliability);
    weight = Math.min(weight, TRUST_GRAPH_VALIDATION.edgeWeightCap); // CAP

    await prisma.trustEdge.update({
      where: { id: existing.id },
      data: {
        successfulCoJobs: newCoJobs,
        economicVolume: newVolume,
        escrowReliability: round4(newReliability),
        weight: round4(weight),
        lastInteraction: new Date(),
      },
    });
  } else {
    let weight = computeEdgeWeight(1, jobAmountSats, escrowSuccess ? 1.0 : 0.0);
    weight = Math.min(weight, TRUST_GRAPH_VALIDATION.edgeWeightCap);

    await prisma.trustEdge.create({
      data: {
        sourceProviderId,
        targetProviderId,
        successfulCoJobs: 1,
        economicVolume: jobAmountSats,
        escrowReliability: escrowSuccess ? 1.0 : 0.0,
        weight: round4(weight),
      },
    });
  }
}

/**
 * v2.2 Edge weight formula with MATURITY-AWARE DECAY:
 *   w = log2(1 + coJobs) × (1 + log10(1 + volume/100)) × reliability
 *       × exp(-coJobs / k_eff)            ← v2.2: maturity-scaled decay
 *       × volumeWeight                    ← VOLUME AUTHENTICITY
 *
 * v2.2: k_eff = decayConstant × maturityFactor
 * At small scales, maturityFactor > 1 (slower decay, more lenient)
 * At large scales, maturityFactor < 1 (faster decay, stricter)
 */
function computeEdgeWeight(
  coJobs: number,
  volume: number,
  reliability: number,
  networkSize?: number,
  diversityScore?: number
): number {
  const frequencyFactor = Math.log2(1 + coJobs);
  const volumeFactor = 1 + Math.log10(1 + volume / 100);

  // v2.2: Maturity-aware decay constant
  const k_eff = effectiveDecayConstant(networkSize ?? 50, diversityScore ?? 0.5);
  const repeatedPairDecay = Math.exp(-coJobs / k_eff);

  // v2.1: Volume authenticity — tiny fake transactions contribute less
  const minVol = ECONOMIC_VOLUME_WEIGHTING.minVolumeForFullWeight;
  const volumeWeight = Math.min(Math.log2(1 + volume / minVol), 1.0);

  return frequencyFactor * volumeFactor * reliability * repeatedPairDecay * volumeWeight;
}

// ─── v2: Edge Diversity Analysis ──────────────────────────────────────────────

/**
 * Compute edge diversity score for a provider.
 * Low diversity (few unique counterparties) → suspicious.
 * Returns [0, 1] where 1 = highly diverse, 0 = single counterparty.
 */
async function computeEdgeDiversity(providerId: string): Promise<number> {
  const outEdges = await prisma.trustEdge.findMany({
    where: { sourceProviderId: providerId },
  });
  const inEdges = await prisma.trustEdge.findMany({
    where: { targetProviderId: providerId },
  });

  // Unique counterparties
  const counterparties = new Set<string>();
  for (const e of outEdges) counterparties.add(e.targetProviderId);
  for (const e of inEdges) counterparties.add(e.sourceProviderId);

  const uniqueCount = counterparties.size;
  const totalEdges = outEdges.length + inEdges.length;

  if (totalEdges === 0) return 0;

  // Diversity: ratio of unique counterparties to total edges
  // A provider with 10 edges to 10 different counterparties = 1.0
  // A provider with 10 edges to 2 counterparties = 0.2
  const diversity = uniqueCount / totalEdges;

  // Also check volume concentration
  const volumes = outEdges.map((e) => e.economicVolume);
  const totalVolume = volumes.reduce((s, v) => s + v, 0);

  if (totalVolume === 0 || volumes.length <= 1) return diversity;

  // Herfindahl index of volume concentration
  const hhi = volumes.reduce((s, v) => s + (v / totalVolume) ** 2, 0);
  // HHI: 1/N = perfectly equal, 1.0 = maximally concentrated
  const concentrationPenalty = Math.max(0, hhi - 1 / volumes.length);

  return Math.max(0, Math.min(1, diversity - concentrationPenalty));
}

// ─── v2: Circular Trust Detection ─────────────────────────────────────────────

/**
 * Detect circular trust patterns (A→B→C→A) for a given provider.
 * Returns the number of cycles involving this provider.
 */
async function detectCircularPatterns(providerId: string): Promise<number> {
  const outEdges = await prisma.trustEdge.findMany({
    where: { sourceProviderId: providerId },
    select: { targetProviderId: true },
  });

  let cycles = 0;

  for (const firstHop of outEdges) {
    // Check for 2-hop cycle: A→B→A
    const returnEdge = await prisma.trustEdge.findUnique({
      where: {
        sourceProviderId_targetProviderId: {
          sourceProviderId: firstHop.targetProviderId,
          targetProviderId: providerId,
        },
      },
    });
    if (returnEdge) cycles++;

    // Check for 3-hop cycle: A→B→C→A
    const secondHops = await prisma.trustEdge.findMany({
      where: { sourceProviderId: firstHop.targetProviderId },
      select: { targetProviderId: true },
    });

    for (const secondHop of secondHops) {
      if (secondHop.targetProviderId === providerId) continue; // Already counted as 2-hop
      const returnFromThird = await prisma.trustEdge.findUnique({
        where: {
          sourceProviderId_targetProviderId: {
            sourceProviderId: secondHop.targetProviderId,
            targetProviderId: providerId,
          },
        },
      });
      if (returnFromThird) cycles++;
    }
  }

  return cycles;
}

// ─── PageRank-Style Network Trust ─────────────────────────────────────────────

/**
 * v2: Compute networkTrust with saturation caps and diversity weighting.
 */
export async function computeAllNetworkTrust(): Promise<Map<string, number>> {
  const DAMPING = 0.85;
  const MAX_ITER = 20;
  const EPSILON = 0.0001;

  const providers = await prisma.provider.findMany({
    where: { isActive: true },
    select: { id: true },
  });
  const edges = await prisma.trustEdge.findMany();

  const N = providers.length;
  if (N === 0) return new Map();

  const providerIds = providers.map((p) => p.id);
  const idToIndex = new Map(providerIds.map((id, i) => [id, i]));

  // Apply temporal decay to edge weights
  const now = Date.now();
  const decayedEdges = edges.map((e) => {
    const age = now - e.lastInteraction.getTime();
    const decayFactor = Math.pow(0.5, age / TRUST_DECAY.halfLifeMs);
    // v2: Apply edge weight cap AFTER decay
    const weight = Math.min(e.weight * decayFactor, TRUST_GRAPH_VALIDATION.edgeWeightCap);
    return {
      source: idToIndex.get(e.sourceProviderId),
      target: idToIndex.get(e.targetProviderId),
      weight,
    };
  }).filter((e) => e.source !== undefined && e.target !== undefined) as Array<{
    source: number;
    target: number;
    weight: number;
  }>;

  // Build adjacency
  const outEdges: Map<number, Array<{ target: number; weight: number }>> = new Map();
  const outWeightSum: number[] = new Array(N).fill(0);

  for (const e of decayedEdges) {
    if (!outEdges.has(e.source)) outEdges.set(e.source, []);
    outEdges.get(e.source)!.push({ target: e.target, weight: e.weight });
    outWeightSum[e.source] += e.weight;
  }

  // Initialize trust
  let trust = new Array(N).fill(1 / N);
  let newTrust = new Array(N).fill(0);

  // Iterate
  for (let iter = 0; iter < MAX_ITER; iter++) {
    newTrust.fill((1 - DAMPING) / N);

    for (let i = 0; i < N; i++) {
      const edges_i = outEdges.get(i);
      if (!edges_i || outWeightSum[i] === 0) continue;

      for (const e of edges_i) {
        newTrust[e.target] += DAMPING * (e.weight / outWeightSum[i]) * trust[i];
      }
    }

    let maxDelta = 0;
    for (let i = 0; i < N; i++) {
      maxDelta = Math.max(maxDelta, Math.abs(newTrust[i] - trust[i]));
    }

    trust = [...newTrust];
    if (maxDelta < EPSILON) break;
  }

  // Normalize to [0, 1] with v2 SATURATION CAP
  const maxTrust = Math.max(...trust, 0.0001);
  const result = new Map<string, number>();
  for (let i = 0; i < N; i++) {
    const normalizedTrust = trust[i] / maxTrust;
    // v2: Apply trust saturation cap (logarithmic dampening)
    const cappedTrust = Math.min(
      normalizedTrust,
      TRUST_GRAPH_VALIDATION.maxNetworkTrust
    );
    result.set(providerIds[i], round4(cappedTrust));
  }

  return result;
}

/**
 * Compute and persist networkTrust for a single provider.
 */
export async function computeNetworkTrust(providerId: string): Promise<number> {
  const allTrust = await computeAllNetworkTrust();
  const trust = allTrust.get(providerId) ?? 0;

  await prisma.provider.update({
    where: { id: providerId },
    data: { networkTrust: trust },
  });

  return trust;
}

/**
 * v2.1: Compute counterparty entropy for a provider.
 *
 * H(A) = -Σ pᵢ·log₂(pᵢ)
 *
 * where pᵢ = fraction of interactions with counterparty i.
 *
 * High entropy = diverse economic interactions (honest behavior)
 * Low entropy = concentrated clique behavior (suspicious)
 *
 * Returns { entropy, diversityScore } where diversityScore ∈ [0, 1].
 */
export async function computeCounterpartyEntropy(
  providerId: string
): Promise<{ entropy: number; diversityScore: number; uniqueCounterparties: number }> {
  const outEdges = await prisma.trustEdge.findMany({
    where: { sourceProviderId: providerId },
    select: { targetProviderId: true, successfulCoJobs: true, economicVolume: true },
  });
  const inEdges = await prisma.trustEdge.findMany({
    where: { targetProviderId: providerId },
    select: { sourceProviderId: true, successfulCoJobs: true, economicVolume: true },
  });

  // Build interaction frequency map: counterpartyId → total interactions
  const interactionMap = new Map<string, number>();
  for (const e of outEdges) {
    interactionMap.set(
      e.targetProviderId,
      (interactionMap.get(e.targetProviderId) ?? 0) + e.successfulCoJobs
    );
  }
  for (const e of inEdges) {
    interactionMap.set(
      e.sourceProviderId,
      (interactionMap.get(e.sourceProviderId) ?? 0) + e.successfulCoJobs
    );
  }

  const uniqueCounterparties = interactionMap.size;
  if (uniqueCounterparties === 0) {
    return { entropy: 0, diversityScore: 0, uniqueCounterparties: 0 };
  }

  // Total interactions
  const totalInteractions = [...interactionMap.values()].reduce((s, v) => s + v, 0);
  if (totalInteractions === 0) {
    return { entropy: 0, diversityScore: 0, uniqueCounterparties };
  }

  // Shannon entropy: H = -Σ pᵢ·log₂(pᵢ)
  let entropy = 0;
  for (const count of interactionMap.values()) {
    const p = count / totalInteractions;
    if (p > 0) {
      entropy -= p * Math.log2(p);
    }
  }

  // diversityScore = clamp(entropy / minEntropyForFullTrust, 0, 1)
  const diversityScore = Math.min(
    entropy / COUNTERPARTY_DIVERSITY.minEntropyForFullTrust,
    1.0
  );

  return {
    entropy: round4(entropy),
    diversityScore: round4(diversityScore),
    uniqueCounterparties,
  };
}

/**
 * v2.2: Persist all network trust with confidence-gated diversity weighting.
 *
 * AdjustedTrust = baseTrust × diversityScore × pairSaturationMultiplier
 *
 * v2.2 improvement: Uses entropy confidence to avoid over-penalizing
 * agents with insufficient interaction history.
 */
export async function persistAllNetworkTrust(): Promise<void> {
  const allTrust = await computeAllNetworkTrust();

  for (const [providerId, baseTrust] of allTrust) {
    // v2.1: Counterparty entropy — THE primary collusion defense
    const { diversityScore, uniqueCounterparties } = await computeCounterpartyEntropy(providerId);

    // v2.2: Get total interactions for confidence gating
    const provider = await prisma.provider.findUnique({
      where: { id: providerId },
      select: { totalJobs: true },
    });
    const totalInteractions = provider?.totalJobs ?? 0;
    const confidence = computeEntropyConfidence(totalInteractions);

    // ANTI-OVER-HARDENING: New agents have few edges by definition.
    // v2.2: Confidence-gated floor — smoother than hard edge-count threshold
    const totalEdgeCount = uniqueCounterparties;
    const confidenceFloor = 0.5 + (0.5 * (1 - confidence)); // Ranges from 1.0 (new) to 0.5 (mature)
    const effectiveDiversityScore = totalEdgeCount < TRUST_GRAPH_VALIDATION.minDiverseEdges
      ? Math.max(diversityScore, confidenceFloor)
      : diversityScore;

    // Providers with low diversity get dampened trust
    let adjustedTrust = baseTrust * effectiveDiversityScore;

    // Also check minimum diverse edges (v2 feature, preserved)
    const minDiverseEdges = TRUST_GRAPH_VALIDATION.minDiverseEdges;
    if (uniqueCounterparties > 0 && uniqueCounterparties < minDiverseEdges) {
      adjustedTrust *= uniqueCounterparties / minDiverseEdges;
    }

    // v2.1: Apply max single-pair contribution cap
    const outEdges = await prisma.trustEdge.findMany({
      where: { sourceProviderId: providerId },
      select: { targetProviderId: true, weight: true },
    });
    if (outEdges.length > 0) {
      const totalWeight = outEdges.reduce((s, e) => s + e.weight, 0);
      const maxPairWeight = Math.max(...outEdges.map((e) => e.weight));
      const maxPairFraction = totalWeight > 0 ? maxPairWeight / totalWeight : 0;

      if (maxPairFraction > REPEATED_PAIR.maxSinglePairContribution) {
        const excess = maxPairFraction - REPEATED_PAIR.maxSinglePairContribution;
        adjustedTrust *= Math.max(0.2, 1 - excess * 2);
      }
    }

    const finalTrust = round4(Math.min(adjustedTrust, TRUST_GRAPH_VALIDATION.maxNetworkTrust));

    await prisma.provider.update({
      where: { id: providerId },
      data: { networkTrust: finalTrust },
    });
  }
}

// ─── v2: Enhanced Sybil Detection ─────────────────────────────────────────────

export interface SybilCluster {
  providerIds: string[];
  clusterDensity: number;
  suspicionScore: number;
  reasons: string[];
}

/**
 * v2: Detect Sybil clusters with enhanced heuristics:
 *   - Dense cluster detection (same as v1)
 *   - Circular pattern penalty (NEW)
 *   - Edge diversity penalty (NEW)
 *   - Uniform weight detection (enhanced)
 */
export async function detectSybilClusters(): Promise<SybilCluster[]> {
  const edges = await prisma.trustEdge.findMany();
  const providers = await prisma.provider.findMany({
    where: { isActive: true },
    select: { id: true, totalJobs: true },
  });

  if (providers.length < 3 || edges.length < 2) return [];

  const clusters: SybilCluster[] = [];

  // Build adjacency map
  const adjacency = new Map<string, Set<string>>();
  const edgeMap = new Map<string, typeof edges[0]>();

  for (const e of edges) {
    if (!adjacency.has(e.sourceProviderId)) adjacency.set(e.sourceProviderId, new Set());
    adjacency.get(e.sourceProviderId)!.add(e.targetProviderId);
    edgeMap.set(`${e.sourceProviderId}→${e.targetProviderId}`, e);
  }

  // Track which providers are already in detected clusters
  const clustered = new Set<string>();

  for (const provider of providers) {
    if (clustered.has(provider.id)) continue;

    const neighbors = adjacency.get(provider.id);
    if (!neighbors || neighbors.size < 2) continue;

    const neighborArray = [...neighbors];
    let mutualEdges = 0;
    const possibleEdges = neighborArray.length * (neighborArray.length - 1);

    for (const n1 of neighborArray) {
      for (const n2 of neighborArray) {
        if (n1 !== n2 && adjacency.get(n1)?.has(n2)) {
          mutualEdges++;
        }
      }
    }

    if (possibleEdges > 0) {
      const density = mutualEdges / possibleEdges;

      // v2: LOWERED threshold from 0.7 to 0.5 for earlier detection
      if (density > 0.5 && neighborArray.length >= 2) {
        const clusterProviders = [provider.id, ...neighborArray];
        const reasons: string[] = [];
        let suspicionBase = density * 0.5;

        reasons.push(`High internal density: ${(density * 100).toFixed(1)}%`);

        // v2: Circular pattern detection with PENALTY
        let circularCount = 0;
        for (const n of neighborArray) {
          if (adjacency.get(n)?.has(provider.id)) {
            circularCount++;
            reasons.push(`Circular: ${provider.id.substring(0, 8)} ↔ ${n.substring(0, 8)}`);
          }
        }
        suspicionBase += Math.min(
          circularCount * TRUST_GRAPH_VALIDATION.circularPenaltyPerCycle,
          TRUST_GRAPH_VALIDATION.maxCircularPenalty
        );

        // v2: Uniform edge weights detection (enhanced)
        const clusterEdgeWeights: number[] = [];
        for (const src of clusterProviders) {
          for (const tgt of clusterProviders) {
            const edge = edgeMap.get(`${src}→${tgt}`);
            if (edge) clusterEdgeWeights.push(edge.weight);
          }
        }

        if (clusterEdgeWeights.length >= 3) {
          const mean = clusterEdgeWeights.reduce((s, w) => s + w, 0) / clusterEdgeWeights.length;
          const variance = clusterEdgeWeights.reduce((s, w) => s + (w - mean) ** 2, 0) / clusterEdgeWeights.length;
          const cv = Math.sqrt(variance) / (mean || 1);

          if (cv < 0.15) { // v2: raised from 0.1 to 0.15 (catch more)
            suspicionBase += 0.2;
            reasons.push(`Uniform edge weights (CV=${cv.toFixed(3)})`);
          }
        }

        // v2: Edge diversity check for cluster members
        let lowDiversityCount = 0;
        for (const pid of clusterProviders) {
          const outNeighbors = adjacency.get(pid);
          const outsideCluster = outNeighbors
            ? [...outNeighbors].filter((n) => !clusterProviders.includes(n)).length
            : 0;
          if (outsideCluster === 0 && (outNeighbors?.size ?? 0) > 0) {
            lowDiversityCount++;
          }
        }
        if (lowDiversityCount > clusterProviders.length * 0.5) {
          suspicionBase += 0.15;
          reasons.push(`${lowDiversityCount}/${clusterProviders.length} members have zero external connections`);
        }

        const suspicionScore = Math.min(suspicionBase, 1.0);

        clusters.push({
          providerIds: clusterProviders,
          clusterDensity: round4(density),
          suspicionScore: round4(suspicionScore),
          reasons,
        });

        for (const pid of clusterProviders) clustered.add(pid);
      }
    }
  }

  return clusters;
}

/**
 * v2: Update sybilRisk for all providers with circular pattern penalties.
 */
export async function updateSybilRiskScores(): Promise<void> {
  const clusters = await detectSybilClusters();

  // Reset all sybil risks
  await prisma.provider.updateMany({
    where: { isActive: true },
    data: { sybilRisk: 0 },
  });

  // Apply cluster-based sybil risk
  for (const cluster of clusters) {
    for (const providerId of cluster.providerIds) {
      const provider = await prisma.provider.findUnique({
        where: { id: providerId },
        select: { sybilRisk: true },
      });

      if (provider) {
        const newRisk = Math.max(provider.sybilRisk, cluster.suspicionScore);
        await prisma.provider.update({
          where: { id: providerId },
          data: { sybilRisk: round4(newRisk) },
        });
      }
    }
  }

  // v2: Additional individual-level checks
  const providers = await prisma.provider.findMany({
    where: { isActive: true },
    select: { id: true, sybilRisk: true },
  });

  for (const p of providers) {
    let additionalRisk = 0;

    // Check circular patterns for each provider
    const cycles = await detectCircularPatterns(p.id);
    if (cycles > 0) {
      additionalRisk += Math.min(
        cycles * TRUST_GRAPH_VALIDATION.circularPenaltyPerCycle,
        TRUST_GRAPH_VALIDATION.maxCircularPenalty
      );
    }

    // Check edge diversity
    const diversity = await computeEdgeDiversity(p.id);
    if (diversity < 0.3) {
      additionalRisk += 0.1; // Low diversity is suspicious
    }

    if (additionalRisk > 0) {
      const finalRisk = Math.min(p.sybilRisk + additionalRisk, 1.0);
      await prisma.provider.update({
        where: { id: p.id },
        data: { sybilRisk: round4(finalRisk) },
      });
    }
  }
}

// ─── Temporal Trust Decay ─────────────────────────────────────────────────────

/**
 * v2: Apply temporal decay with inactivity penalties.
 */
export async function applyTemporalDecay(): Promise<number> {
  const edges = await prisma.trustEdge.findMany();
  const now = Date.now();
  let updatedCount = 0;

  for (const edge of edges) {
    const age = now - edge.lastInteraction.getTime();
    const decayFactor = Math.pow(0.5, age / TRUST_DECAY.halfLifeMs);

    if (decayFactor < 0.95) {
      const newWeight = round4(edge.weight * decayFactor);

      if (newWeight < 0.01) {
        await prisma.trustEdge.delete({ where: { id: edge.id } });
      } else {
        await prisma.trustEdge.update({
          where: { id: edge.id },
          data: { weight: newWeight },
        });
      }
      updatedCount++;
    }
  }

  return updatedCount;
}

// ─── Utility ──────────────────────────────────────────────────────────────────

function round4(n: number): number {
  return Math.round(n * 10000) / 10000;
}
