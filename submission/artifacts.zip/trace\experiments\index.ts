export { runExperiment, DEFAULT_CONFIG, MODEL_PRESETS, type ExperimentConfig, type AgentModelSpec } from "./runner";
export {
  computeRoundMetrics,
  aggregateMetrics,
  roundMetricsToCSV,
  scoreHistoryToCSV,
  type RoundMetrics,
  type ExperimentMetrics,
} from "./metrics";
export {
  descriptiveStats,
  mannWhitneyU,
  detectOutliers,
  aggregateMultiSeed,
  formatPctStat,
  formatSatsStat,
  formatSignificance,
  generateComparisonTable,
  type DescriptiveStats,
  type MannWhitneyResult,
  type OutlierReport,
  type MultiSeedMetrics,
  type ExperimentResult,
} from "./statistics";
